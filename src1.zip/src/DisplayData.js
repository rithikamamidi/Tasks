import React, { Component } from 'react';

class DisplayFetchedData extends Component {
  render() {
    return (
      <div>
          {this.props.data.title}
      </div>
    );
  }
}

export default DisplayFetchedData;
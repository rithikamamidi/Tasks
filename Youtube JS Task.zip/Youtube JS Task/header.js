var header = document.createElement("DIV");
var youtubelogo = document.createElement("IMG");
youtubelogo.setAttribute("src", "youtube-logo.jpg");
youtubelogo.className="logoStyle";
var searchDiv = document.createElement("DIV");
searchDiv.className="searchDivStyle"
var searchBox = document.createElement("INPUT");
searchBox.setAttribute("type", "text");
searchBox.className="searchBox";
searchBox.addEventListener("keyup",()=>console.log(searchBox.value))
searchBox.setAttribute("placeholder", "Search");
var searchButton = document.createElement("BUTTON");
var searchText = document.createTextNode("Search");
searchButton.className="searchButtonStyle";
searchButton.appendChild(searchText);
searchDiv.append(searchBox, searchButton);
header.className="headerStyle";
header.append(youtubelogo, searchDiv)
document.body.appendChild(header);
var searchResults=document.createElement("DIV");
searchResults.setAttribute('id','searchResults')
document.body.appendChild(searchResults);
var resultData = [];
function searchButtonClicked() {
    resultData=[];
    fetch("https://www.googleapis.com/youtube/v3/search?" +
        "key=AIzaSyCTWC75i70moJLzyNh3tt4jzCljZcRkU8Y&type=video&part=snippet&maxResults=15&q="+searchBox.value)
        .then((response) => {
            response.json().then(function (data) {
                console.log(data.items);
                resultData = data.items;
                displayData();
            });
        })
}
searchButton.addEventListener("click", searchButtonClicked);
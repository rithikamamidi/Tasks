function displayData() {
    console.log(resultData[0].snippet.thumbnails.default.url)
    console.log(resultData);
    while (searchResults.firstChild) {
        searchResults.removeChild(searchResults.firstChild);
    }
    for (resultRecord of resultData) {
        var result = document.createElement("DIV");
        result.className="resultStyle"
        var image = document.createElement("IMG");
        image.setAttribute("src", resultRecord.snippet.thumbnails.high.url);
        image.className="imageClass"
        var descriptionDiv = document.createElement("DIV");
        var channelTitle=document.createElement("P");
        var channelTitleText = document.createTextNode(resultRecord.snippet.channelTitle);
        channelTitle.appendChild(channelTitleText);
        var description=document.createElement("P");
        var descriptionText = document.createTextNode((resultRecord.snippet.title).substring(0,100));
        description.appendChild(descriptionText);
        description.className="descriptionText";
        descriptionDiv.append(description, channelTitle);
        result.append(image, descriptionDiv);
        document.getElementById('searchResults').appendChild(result);
    }
}
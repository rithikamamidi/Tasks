package com.epam.engx.cleancode.naming.task1.thirdpartyjar;

public interface NotificationManager {
    void notifyCustomer(Message message, int level);
}

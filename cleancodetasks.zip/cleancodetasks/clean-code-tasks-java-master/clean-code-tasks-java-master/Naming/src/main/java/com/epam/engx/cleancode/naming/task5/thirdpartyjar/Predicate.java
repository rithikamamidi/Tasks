package com.epam.engx.cleancode.naming.task5.thirdpartyjar;

public interface Predicate<T> {

    boolean test(T fileName);
}

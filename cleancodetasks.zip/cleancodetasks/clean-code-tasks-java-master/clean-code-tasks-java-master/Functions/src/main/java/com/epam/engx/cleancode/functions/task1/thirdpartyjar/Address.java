package com.epam.engx.cleancode.functions.task1.thirdpartyjar;

public interface Address {
}

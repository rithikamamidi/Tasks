package com.epam.engx.cleancode.functions.task4.stubs;

public class AvailableProductStub extends AbstractProductStub {
    @Override
    public boolean isAvailable() {
        return true;
    }
}

Packages with name "...thirdpartyjar" are used for unchangeble things. Threr is assumption that it cannot be changed.
It's used only for providing a context to task and it's not the part of the task.

import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
// import createHistory from 'history/createBrowserHistory'
import history from './history'
import {Router,Route, Switch} from 'react-router';
import App from './App';
import NotFound from './NotFound'
// const history = createHistory();
// history.push("/");
// const location = history.location;
//console.log("location is"+location);
ReactDOM.render(
<Router history={history}>
<Switch>
    <Route path = "/hhh" component = {NotFound}/>
    <Route path = "/" component = {App}/>
</Switch>
</Router>, document.getElementById('root'));

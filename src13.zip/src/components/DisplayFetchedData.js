import React, { Component } from 'react';
import MoviePoster from './MoviePoster';
import '../css/displayData.css'
class DisplayFetchedData extends Component {
  render() {
    return (
      <div className="displayInGrid">
            <div className="movieResults">
              {this.props.data.map(i => {
                return <MoviePoster key={i['id']} data={i}/>
              })}
            </div>
      </div>
    );
  }
}
export default DisplayFetchedData;
import { combineReducers } from 'redux'
import {isLoaded,isLoading,data,searchCriteria,
    sortCriteria,searchText,relatedData,
    isRelatedDataLoaded} from './reducer'

export default combineReducers({
    isLoaded,
    isLoading,
    data,
    searchCriteria,
    sortCriteria,
    searchText,
    relatedData,
    isRelatedDataLoaded
});
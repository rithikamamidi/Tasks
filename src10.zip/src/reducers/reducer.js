const reducer = (state = [], action) => {
    switch (action.type) {
      case 'FETCH_DATA':
      console.log("reduxer"); 
       return [
         {
           text:'hello'
         }
       ]
      case 'SET_DATA':
       console.log("setting data");
       return action.data
       
      default:
        return state
    }
  }
  export default reducer
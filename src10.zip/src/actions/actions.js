
export  const  changeSearchCriteria = (clickedId)=>({
    type:'CHANGE_SEARCH_CRITERIA',
    clickedId
})
export const changeSortCriteria = (clickedId)=>({
    type:'CHANGE_SORT_CRITERIA',
    clickedId
})
export const changeSearchText = (text)=>({
    type:'CHANGE_SEARCH_TEXT',
    text
})
export const fetchData = () => ({
    type:'FETCH_DATA',
    text:'fetching data action'
})
export const setData = (data) =>({
    type:'SET_DATA',
    data
})
export function itemsIsLoading(bool) {
    return {
        type: 'ITEMS_IS_LOADING',
        isLoading: bool
    };
}
export function fetchDataFunction(url) {
    return (dispatch) => {
        dispatch(itemsIsLoading(true));

        fetch(url)
            .then((response) => {
                if (!response.ok) {
                    throw Error(response.statusText);
                }

                dispatch(itemsIsLoading(false));

                return response;
            })
            .then((response) => response.json())
            .then(jsonData=>jsonData["data"])
            .then((data) => dispatch(setData(data)))
            // .catch(() => dispatch(itemsHasErrored(true)));
    };
}



import React, { Component } from 'react';
import MoviePoster from './Movie';
import './displayData.css'
class DisplayFetchedData extends Component {
  clicked(){
    console.log("hello in display");
  }
  render() {
    return (
      <div className="displayInGrid">
          {/* <div className="">
              <label>{this.props.data.result.length} films found</label>
              <label className="">Sort by</label>
              <button value="release date">Release Date</button>
              <button value="rating">Rating</button>
            </div> */}
            <div className="movieResults">
              {this.props.data.result.map(i => {
                return <MoviePoster key={i['id']} data={i} onClick={this.clicked()}/>
              })}
            </div>
            
      </div>
    );
  }
}

export default DisplayFetchedData;
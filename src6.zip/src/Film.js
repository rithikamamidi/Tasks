
import React, { Component } from 'react';
import './Film.css';
import MoviePoster from './Movie'

class Film extends Component {
    constructor(props) {
        super(props);
        this.state = {id:this.props.location.state.id,dataLoaded:false,fetchedData:{},relatedData:{}};
      }
      async componentDidMount(){
        console.log(this.props.location.state.id)
        console.log(this.state.fetchedData);
        var data=this.props.location.state.id;
        var query="http://react-cdp-api.herokuapp.com/movies/"+this.props.location.state.id;
             await fetch(query).then(result=>result.json())
            .then(result=>this.setState({fetchedData:{result}}))
            
        var query2="http://react-cdp-api.herokuapp.com/movies?search=horror&searchBy=genres&limit=50";
        await fetch(query2).then(result=>result.json())
            .then(jsonData=>jsonData["data"])
            .then(result=>this.setState({relatedData:{result}}))
            .then(()=>this.setState({dataLoaded:true}))
            console.log(this.state.relatedData);

      }
      clicked(id){
        this.setState({id:{id}});
        console.log("in clicked")
        console.log(this.state.id);

      }
    render() {
      console.log(this.state.dataLoaded);
      console.log(this.state.fetchedData)
      if(this.state.dataLoaded){
        return (
          <div className="bgblack">
            <img src={this.state.fetchedData.result.poster_path} alt="alternate" className="imageStyle1"/>
            <div className="floatLeft">
              <h3>{this.state.fetchedData.result.title}</h3>
              <p>{this.state.fetchedData.result.tagline}</p>
              <div className="divWidth">
                <label>{this.state.fetchedData.result.release_date.substring(0, 4)}</label>
                <label class="floatRight">{this.state.fetchedData.result.runtime} mins</label>
              </div>
              <p>{this.state.fetchedData.result.overview}</p>
          </div>

          <div className="displayInGrid">
          {/* <div className="">
              <label>{this.props.data.result.length} films found</label>
              <label className="">Sort by</label>
              <button value="release date">Release Date</button>
              <button value="rating">Rating</button>
            </div> */}
            <div className="movieResults">
              {this.state.relatedData.result.map(i => {
                return <MoviePoster key={i['id']} data={i} onClick={()=>this.clicked(i['id'])}/>
              })}
            </div>
            
      </div>
          </div>
        )
      }
      else {
        return <h1>loading</h1>
      }
    }
  }
  export default Film;
import React, { Component } from 'react';
import './Search.css';
import DisplayFetchedData from './DisplayData';

class Search extends Component {
    constructor(props) {
        super(props);
        this.searchInput = React.createRef();
        this.state = {title:true,rating:false,dataLoaded:false,searchByName:'',fetchedData:{}};
        this.handleChange = this.handleChange.bind(this);
        this.handleSearch = this.handleSearch.bind(this);
        this.handleSort = this.handleSort.bind(this);
        this.updateSearchValue = this.updateSearchValue.bind(this);
      }
    
      handleChange(event) {
          if(event.target.id==="title"){
              this.setState({title:true})
              console.log(this.state.title+""+this.state.genre);
          } else{
              this.setState({title:false})
              console.log(this.state.title+""+this.state.genre);
          }
        }
        handleSort(event) {
            if(event.target.id==="rating"){
                this.setState({rating:true})
                console.log(this.state.rating);
            } else{
                this.setState({rating:false})
                console.log(this.state.rating);
            }
          }
       handleSearch= async(event)=> {
           event.preventDefault();
          var searchCriteria = this.state.title ? "title" : "genres";
          var sortCriteria = this.state.rating ? "rating" : "release_date"
          var query="http://react-cdp-api.herokuapp.com/movies?sortBy="+sortCriteria+"&search="+this.state.searchByName+"&searchBy="+searchCriteria+"&limit=50";
          await fetch(query)
            .then(results =>{
                return results.json();
            })
            .then(jsonData=>jsonData["data"])
            .then(result=>this.setState({fetchedData:{result}}))
            console.log(this.state.fetchedData);
            this.setState({dataLoaded:true})
      }
      updateSearchValue(e){
        this.setState({
            searchByName:e.target.value
        })
      }
      callDisplay(dataLoaded){
          console.log("inside call display");
         if(dataLoaded){
             return (
                 <>
                    <div className="bgBlackColor">
                        <label>{this.state.fetchedData.result.length} films found</label>
                        <div className="alignEnd">
                            <label className="">Sort by</label>
                            <button value="release date" className="criteriaButton" id="release_date" onClick={this.handleSort}>Release Date</button>
                            <button value="rating" className="criteriaButton" id="rating" onClick={this.handleSort}>Rating</button>
                        </div>
                    </div>
                    {this.state.fetchedData.result.length!==0 ? (<DisplayFetchedData data={this.state.fetchedData}/>) : (<h1>No films found</h1>)}
                    
                </>
             )
             
         }
         return <h1 className="alignCenter">Search for movies</h1>
      }
    render() {
       return (
           <div className="backgroundBlack">
               <div className="div">
                    <p className="redText">netflix application</p>
                    <form className="form">
                        <label className="label">
                            FIND YOUR MOVIE<br/>
                        </label>
                        <input type="text" name="name" className="searchBox" onChange={this.updateSearchValue}/>
                        <br/>
                        <div className="buttonDiv">
                            <span className="spanStyle">Search by</span>
                            <input type="button" value="TITLE" className="criteriaButton" id="title" onClick={this.handleChange}/>
                            <input type="button" value="GENRE" className="criteriaButton" id="genre" onClick={this.handleChange}/>
                            <input type="submit" value="SEARCH" className="searchButton" onClick={this.handleSearch}/>
                        </div>
                    </form>    
                </div>
                {this.callDisplay(this.state.dataLoaded)}     
           </div>
           
      );
    }
  }
  export default Search;
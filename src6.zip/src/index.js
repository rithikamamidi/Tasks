import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
// import createHistory from 'history/createBrowserHistory'
import history from './history'
import {Router,Route, Switch} from 'react-router';
import App from './App';
import Film from './Film';
import NotFound from './NotFound'
// const history = createHistory();
// history.push("/");
// const location = history.location;
//console.log("location is"+location);
ReactDOM.render(
<Router history={history}>
<Switch>
    <Route path = "/film" component = {Film}/>
    <Route exact path = "/" component = {App}/>
    <Route path="/*" component={NotFound}/>
</Switch>
</Router>, document.getElementById('root'));

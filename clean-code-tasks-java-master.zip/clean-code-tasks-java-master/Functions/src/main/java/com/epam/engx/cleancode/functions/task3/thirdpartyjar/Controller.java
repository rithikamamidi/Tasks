package com.epam.engx.cleancode.functions.task3.thirdpartyjar;

public interface Controller {

    void generateSuccessLoginResponse(String user);

    void generateFailLoginResponse();
}

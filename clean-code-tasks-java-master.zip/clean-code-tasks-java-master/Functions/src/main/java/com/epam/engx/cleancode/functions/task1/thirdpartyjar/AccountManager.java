package com.epam.engx.cleancode.functions.task1.thirdpartyjar;

public interface AccountManager {
    void createNewAccount(Account account);
}

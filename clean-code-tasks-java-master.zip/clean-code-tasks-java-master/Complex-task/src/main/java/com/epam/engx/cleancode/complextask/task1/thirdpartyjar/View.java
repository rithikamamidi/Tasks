package com.epam.engx.cleancode.complextask.task1.thirdpartyjar;

public interface View {
    void write(String message);

    String read();

}
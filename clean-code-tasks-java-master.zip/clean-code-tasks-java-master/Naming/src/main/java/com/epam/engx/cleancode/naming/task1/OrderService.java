package com.epam.engx.cleancode.naming.task1;

import com.epam.engx.cleancode.naming.task1.thirdpartyjar.Order;

public interface OrderService {
    void submitOrder(Order order);
}

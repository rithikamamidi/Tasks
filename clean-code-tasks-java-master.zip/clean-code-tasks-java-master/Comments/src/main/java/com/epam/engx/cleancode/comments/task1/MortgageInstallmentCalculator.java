package com.epam.engx.cleancode.comments.task1;

import com.epam.engx.cleancode.comments.task1.thirdpartyjar.InvalidInputException;

public class MortgageInstallmentCalculator {
    public static double calculateMonthlyPayment(
            int principleAmount, int termOfMortgageInyears, double rateOfInterest) {
        if (principleAmount < 0 || termOfMortgageInyears <= 0 || rateOfInterest < 0) {
            throw new InvalidInputException("Negative values are not allowed");
        }
        // Convert interest rate into a decimal - eg. 6.5% = 0.065
        rateOfInterest /= 100.0;
        double monthlyPayment;

        double termOfMortgageInMonths = termOfMortgageInyears * 12;
        if(rateOfInterest==0)
            monthlyPayment = principleAmount/termOfMortgageInMonths;
        else {
        	double monthlyRate = rateOfInterest / 12.0;
        	// The Math.pow() method is used calculate values raised to a power
        	monthlyPayment = (principleAmount * monthlyRate) / (1 - Math.pow(1 + monthlyRate, -termOfMortgageInMonths));
        }
        return monthlyPayment;
    }
}

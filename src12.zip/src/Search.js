import React, { Component } from 'react';
import './Search.css';
import DisplayFetchedData from './DisplayData';
import {fetchDataFunction,changeSearchCriteria,changeSortCriteria,changeSearchText} from './actions/actions';
import { connect } from 'react-redux'

class Search extends Component {
    constructor(props) {
        super(props);
        this.searchInput = React.createRef();
        this.updateSearchValue = this.updateSearchValue.bind(this);
    }
    handleSearchCriteriaChange=(event) =>{
        this.props.changeSearchCriteria(event.target.id);
    }
    handleSort=(event)=> {
        this.props.changeSortCriteria(event.target.id);
    }
    handleSearch=(event)=>{
        var query="http://react-cdp-api.herokuapp.com/movies?sortBy="+this.props.sortCriteria+
            "&sortOrder=desc&search="+this.props.searchText
            +"&searchBy="+this.props.searchCriteria+"&limit=50";
        console.log("inside search");
        this.props.fetchDataFn(query);
    }
    updateSearchValue(event){
        this.props.updateSearchText(event.target.value);
    }
    callDisplay(dataLoaded,isloading){
        console.log("inside call display");
        if(!dataLoaded && !isloading){
            return <h1 className="alignCenter">Search for movies</h1>
        }
        else if(isloading && !dataLoaded){
            return <h1>loading..</h1>
        }
        return (
            <>
            <div className="bgBlackColor">
                <label>{this.props.data.length} films found</label>
                <div className="alignEnd">
                    <label className="">Sort by</label>
                    <button value="release date" className="criteriaButton" id="release_date" onClick={this.handleSort}>Release Date</button>
                    <button value="rating" className="criteriaButton" id="vote_average" onClick={this.handleSort}>Rating</button>
                </div>
            </div>
            {this.props.data.length!==0 ? (<DisplayFetchedData data={this.props.data}/>) : (<h1>No films found</h1>)}
            </>
        )
    }
    render() {
       return (
           <div className="backgroundBlack">
               <div className="div">
                    <div className="text">
                        <p className="redText">netflix application</p>
                        <form className="form">
                            <label className="label">
                                FIND YOUR MOVIE<br/>
                            </label>
                            <input type="text" name="name" className="searchBox" onChange={this.updateSearchValue}/>
                            <br/>
                            <div className="buttonDiv">
                                <span className="spanStyle">Search by</span>
                                <input type="button" value="TITLE" className="criteriaButton" id="title" onClick={this.handleSearchCriteriaChange}/>
                                <input type="button" value="GENRE" className="criteriaButton" id="genres" onClick={this.handleSearchCriteriaChange}/>
                                <input type="button" value="SEARCH" className="searchButton" onClick={this.handleSearch}/>
                            </div>
                        </form>    
                    </div>
                </div>
                {this.callDisplay(this.props.isLoaded,this.props.isLoading)}     
           </div>
           
      );
    }
  }
  const mapStateToProps = state => ({
      data:state.data,
      isLoaded: state.isLoaded,
      searchCriteria:state.searchCriteria,
      sortCriteria:state.sortCriteria,
      searchText:state.searchText,
      isLoading:state.isLoading
  });
  const mapDispatchToProps = dispatch => ({
      fetchDataFn: (url) => dispatch(fetchDataFunction(url)),
      changeSearchCriteria: (searchCriteria)=>dispatch(changeSearchCriteria(searchCriteria)),
      updateSearchText: (searchText)=>dispatch(changeSearchText(searchText)),
      changeSortCriteria:(sortCriteria)=>dispatch(changeSortCriteria(sortCriteria))
});
export default connect(mapStateToProps,mapDispatchToProps)(Search);
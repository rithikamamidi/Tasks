
export  const  changeSearchCriteria = (searchCriteria)=>({
    type:'CHANGE_SEARCH_CRITERIA',
    searchCriteria
})
export const changeSortCriteria = (sortCriteria)=>({
    type:'CHANGE_SORT_CRITERIA',
    sortCriteria
})
export const changeSearchText = (searchText)=>({
    type:'CHANGE_SEARCH_TEXT',
    searchText
})
export const setData = (data) =>({
    type:'FETCHED_DATA',
    data
})
export function dataIsLoaded(bool) {
    return {
        type: 'IS_LOADED',
        isLoaded: bool
    };
}
export function isLoading(isLoading) {
    return {
        type:'IS_LOADING',
        isLoading
    }
}
export function fetchDataFunction(url) {
    return (dispatch) => {
         dispatch(isLoading(true));

        fetch(url)
            .then((response) => {
                if (!response.ok) {
                    throw Error(response.statusText);
                }
                return response;
            })
            .then((response) => response.json())
            .then(jsonData=>jsonData["data"])
            .then((data) => dispatch(setData(data)))
            .then(()=>dispatch(dataIsLoaded(true)))
            .then(()=>dispatch(isLoading(false)))
    };
}

export const getDataBasedOnId=(url)=>{
    console.log("in get data");
    return (dispatch) => {
        // dispatch(isLoading(true));

       fetch(url)
           .then((response) => {
               if (!response.ok) {
                   throw Error(response.statusText);
               }
               console.log(response)
               return response;
           })
           .then((response) => response.json())
           .then(jsonData=>{
               console.log(jsonData)
            return jsonData;
        
           })
           .then((data) => dispatch(setDataBasedOnId(data)))
        //    .then(()=>dispatch(setRelatedDataLoaded(true)))
        //    .then(()=>console.log("hii"))
        //    .then(()=>dispatch(isLoading(false)))
   };

} 

export const getRelatedData=(url)=>{
    console.log("in get data");
    return (dispatch) => {
        // dispatch(isLoading(true));

       fetch(url)
           .then((response) => {
               if (!response.ok) {
                   throw Error(response.statusText);
               }
               console.log(response)
               return response;
           })
           .then((response) => response.json())
           .then(jsonData=>{
               console.log(jsonData)
            return jsonData["data"];
        
           })
           .then((data) => dispatch(setRelatedData(data)))
           .then(()=>dispatch(setRelatedDataLoaded(true)))
        //    .then(()=>console.log("hii"))
        //    .then(()=>dispatch(isLoading(false)))
   };

} 



export function setDataBasedOnId(dataBasedOnId) {
    return {
        type:'DATA_BASED_ON_ID',
        dataBasedOnId
    }
}
export function setRelatedDataLoaded(isRelatedDataLoaded) {
    return {
        type:'IS_RELATED_DATA_LOADED',
        isRelatedDataLoaded
    }
}
export function setRelatedData(relatedData) {
    return {
        type:'RELATED_DATA',
        relatedData
    }
}


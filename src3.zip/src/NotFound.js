import React, { Component } from 'react';
class NotFound extends Component {
    render() {
      // const greeting = 'Welcome to React';
      return (
        <div>
            <h1>Not found</h1>
        </div>
      );
    }
  }
  
  export default NotFound;
  
import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import createHistory from 'history/createBrowserHistory'
import {Router,Route, Switch} from 'react-router';
import App from './App';
import NotFound from './NotFound'
const history = createHistory();
ReactDOM.render(
<Router history={history}>
<Switch>
    <Route path = "/hhh" component = {NotFound}/>
    <Route path = "/" component = {App}/>
</Switch>
</Router>, document.getElementById('root'));

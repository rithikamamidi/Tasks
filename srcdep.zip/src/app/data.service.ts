import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private http: HttpClient) {
    
   }
  get(){
    // return this.data[0];
    return this.http.get('http://demo3060364.mockable.io/carePlanList');
  }
  // data=[
    
  //   {
  //     "items": [
  //         {
  //             "name": "Action",
  //             "children": [
  //                 {
  //                     "name": "Special Academy Pizza",
  //                     "information": "Pastrami pork belly ball tip andouille corned beef jerky shankle landjaeger. Chicken chuck porchetta picanha, ham brisket tenderloin venison meatloaf landjaeger jowl.",
  //                     "price": "$25"
  //                 },
  //                 {
  //                     "name": "Pizza Ionic",
  //                     "information": "Pork chop meatloaf rump, meatball shoulder turducken alcatra doner sausage capicola pork strip steak turkey cupim leberkas.",
  //                     "price": "$19.99"
  //                 }
  //             ]
  //         },
  //         {
  //             "name": "Pizza",
  //             "children": [
  //                 {
  //                     "name": "Traditional",
  //                     "children": [
  //                         {
  //                             "name": "Pizza Salami",
  //                             "information": "Pork chop jowl capicola porchetta, kielbasa prosciutto boudin bacon pork pig.",
  //                             "price": "$10"
  //                         },
  //                         {
  //                             "name": "Pizza Prosciutto",
  //                             "information": "Pork chop pastrami landjaeger chuck brisket",
  //                             "price": "$12"
  //                         }
  //                     ]
  //                 },
  //                 {
  //                     "name": "Gourmet",
  //                     "children": [
  //                         {
  //                             "name": "Pizza Bombay",
  //                             "information": "Pastrami ham hock ball tip, tongue ribeye chuck ham beef bresaola leberkas.",
  //                             "price": "$13"
  //                         },
  //                         {
  //                             "name": "Pizza Crazy Dog",
  //                             "information": "Andouille spare ribs meatloaf swine ground round pork loin, brisket chuck bacon tongue.",
  //                             "price": "$14"
  //                         },
  //                         {
  //                             "name": "Pizza Italia",
  //                             "information": "Ribeye ham t-bone, tail ground round biltong picanha sausage rump corned beef.",
  //                             "price": "$11"
  //                         },
  //                         {
  //                             "name": "Pizza Tuna",
  //                             "information": "Pork chop pastrami landjaeger chuck brisket",
  //                             "price": "$14"
  //                         }
  //                     ]
  //                 },
  //                 {
  //                     "name": "Bestseller",
  //                     "children": [
  //                         {
  //                             "name": "Pizza Academy",
  //                             "information": "Frankfurter tail capicola cupim shankle salami, beef ribs beef boudin porchetta ball tip leberkas turkey tenderloin.",
  //                             "price": "$25"
  //                         },
  //                         {
  //                             "name": "Pizza Ionic",
  //                             "information": "Shank chuck tail, kevin shankle ham hock pork loin pork hamburger beef ribs.",
  //                             "price": "$19.99"
  //                         }
  //                     ]
  //                 }
  //             ]
  //         },
  //         {
  //             "name": "Drinks",
  //             "children": [
  //                 {
  //                     "name": "Special Academy Pizza",
  //                     "information": " Landjaeger fatback shank frankfurter, tongue shoulder ham strip steak pancetta pork short loin corned beef short ribs biltong cow",
  //                     "price": "$25"
  //                 },
  //                 {
  //                     "name": "Pizza Ionic",
  //                     "information": "Pork chop pastrami landjaeger chuck brisket",
  //                     "price": "$19.99"
  //                 }
  //             ]
          }
      ]
    }
  ]

}

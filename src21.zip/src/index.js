import React from 'react';
import ReactDOM from 'react-dom';
import './css/index.css';
// import history from './history/history'
import thunk from 'redux-thunk';
import { createStore,applyMiddleware } from 'redux'
import { Provider } from 'react-redux'
import {Route, Switch} from 'react-router';
import {BrowserRouter as Router} from 'react-router-dom';
import Search from './components/Search';
import Film from './components/Film';
import NotFound from './components/NotFound'
import reducer from './reducers/mainreducer'
const store = createStore(reducer,applyMiddleware(thunk))
ReactDOM.render(
<Provider store={store}>
 {/* <Router history={history}> */}
 <Router>
<Switch>
    <Route path = "/film/:id" component = {Film}/>
    <Route exact path = "/" component = {Search}/>
    <Route path="/*" component={NotFound}/>
</Switch>
</Router>
</Provider>
, document.getElementById('root'));

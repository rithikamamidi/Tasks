import React from 'react';
import {Search} from '../components/Search';
import renderer from 'react-test-renderer';
import Enzyme, { shallow,mount } from 'enzyme';
import { mapStateToProps, mapDispatchToProps } from '../components/Search';
import Adapter from 'enzyme-adapter-react-16'
it('Search component renders correctly', () => {
    const SearchComponent = renderer.create(<Search/>).toJSON();
    expect(SearchComponent).toMatchSnapshot();
  }) 

Enzyme.configure({ adapter: new Adapter() })
function setup() {
  const props = {
    changeSearchCriteria:jest.fn(),
    changeSortCriteria:jest.fn(),
    setSortedData:jest.fn(),
    updateSearchText:jest.fn(),
    data:[{"title":"Abcd","release_date":'2014',"genres":['abc','def']},
    {"title":"Abcd2","release_date":'2017',"genres":['abc','def']},
    {"title":"Abcd3","release_date":'2012',"genres":['abc','def']},
    {"title":"Abcd4","release_date":'2017',"genres":['abc','def']}],
    fetchDataFn:jest.fn(),
    isLoaded:true,
    isLoading:false
  }
  const enzymeWrapper = shallow(<Search {...props} />)
  return {
    props,
    enzymeWrapper
  }
}
it('check button click', () => {
    const { enzymeWrapper,props } = setup();
    // const spy = jest.spyOn(enzymeWrapper.instance(), 'handleSearchCriteriaChange');
    // enzymeWrapper.update();
    // const titlebutton=enzymeWrapper.find('#title');
    // const mockedEvent = { target: {} }
    // titlebutton.simulate('click',mockedEvent);
    // expect(spy).toHaveBeenCalled();

    enzymeWrapper.instance().handleSearchCriteriaChange = jest.fn();

enzymeWrapper.update();

enzymeWrapper.find('#title').simulate('click', { target: { } });

expect(enzymeWrapper.instance().handleSearchCriteriaChange).toHaveBeenCalled();


  
    const genresbutton=enzymeWrapper.find('#genres');
    const mockedEvent1 = { target: {} }
    genresbutton.simulate('click',mockedEvent1);
    expect(spy).not.toHaveBeenCalled();

    const searchButton=enzymeWrapper.find('.searchButton');
    searchButton.simulate('click');

    const releaseDateButton=enzymeWrapper.find('#release_date');
    const mockedEvent2 = { target: {} }
    releaseDateButton.simulate('click',mockedEvent2);


    const searchText=enzymeWrapper.find('.searchBox');
    searchText.simulate('change',{target: {value: 'kill'}});
    searchText.simulate('keypress', {key: 'Enter',
        preventDefault: () => {}});
  })


  describe('testing map state to props and map dispatch to props', () => {
    it('testing map state to props', () => {
        const initialState = {
            isLoaded:false
        };
        expect(mapStateToProps(initialState).isLoaded).toEqual(false);
    });
    it('testing changeSearchCriteria in map dispatch to props', () => {
        const dispatch = jest.fn();
        mapDispatchToProps(dispatch).changeSearchCriteria("title");
        expect(dispatch.mock.calls[0][0]).toEqual({
          type: 'CHANGE_SEARCH_CRITERIA',
          searchCriteria:"title"
        });
    });
  it('testing updateSearchText in map dispatch to props', () => {
    const dispatch = jest.fn();
    mapDispatchToProps(dispatch).updateSearchText("kill");
    expect(dispatch.mock.calls[0][0]).toEqual({
      type: 'CHANGE_SEARCH_TEXT',
      searchText:"kill"
    });
  });
  it('testing setSortedData in map dispatch to props', () => {
    const dispatch = jest.fn();
    mapDispatchToProps(dispatch).setSortedData("data");
    expect(dispatch.mock.calls[0][0]).toEqual({
      type: 'FETCHED_DATA',
      data:"data"
    });
  });
  it('testing changeSortCriteria in map dispatch to props', () => {
    const dispatch = jest.fn();
    mapDispatchToProps(dispatch).changeSortCriteria("vote_average");
    expect(dispatch.mock.calls[0][0]).toEqual({
      type: 'CHANGE_SORT_CRITERIA',
      sortCriteria:"vote_average"
    });
  });

  // it('testing fetchDataFn in map dispatch to props', () => {
  //   const dispatch = jest.fn();
  //   mapDispatchToProps(dispatch).fetchDataFn("http://react-cdp-api.herokuapp.com/movies?search=kill&searchBy=title&limit=50");
  //   expect(dispatch.mock.calls[0][0]).toEqual("");
  // });
});
import {isLoading,isLoaded, data, searchCriteria,sortCriteria, searchText, relatedData, isRelatedDataLoaded} from '../reducers/reducer'
import mainreducer from '../reducers/mainreducer'
describe('reducer', () => {
    it('should handle IS_LOADING when state is given correct action is given', () => {
      expect(
        isLoading({}, {
          type: 'IS_LOADING',
          isLoading:true
        })
      ).toEqual(true)
    })

    it('should handle IS_LOADING when state is not given and when wrong action is sent', () => {
        expect(
          isLoading(undefined, {
            type: 'IS_LOADINGG',
            isLoading:true
          })
        ).toEqual(false)
      })

    it('should handle IS_LOADED when state is given and correct action is passed', () => {
        expect(
          isLoaded({}, {
            type: 'IS_LOADED',
            isLoaded:true
          })
        ).toEqual(true)
      })

      it('should handle IS_LOADED when state is not given and wrong action is passed', () => {
        expect(
          isLoaded(undefined, {
            type: 'IS_LOADE',
            isLoaded:true
          })
        ).toEqual(false)
      })

      it('should handle FETCHED_DATA when correct action is passed', () => {
        expect(
          data({}, {
            type: 'FETCHED_DATA',
            data:"text"
          })
        ).toEqual("text")
      })

      it('should handle FETCHED_DATA when wrong action is passed', () => {
        expect(
          data(undefined, {
            type: 'FETCHED_DATAA',
            data:"text"
          })
        ).toEqual([])
      })

      it('should handle CHANGE_SEARCH_CRITERIA when correct action is passed', () => {
        expect(
           searchCriteria({}, {
            type: 'CHANGE_SEARCH_CRITERIA',
            searchCriteria:"title"
          })
        ).toEqual("title")
      })

      it('should handle CHANGE_SEARCH_CRITERIA when wrong action is passed', () => {
        expect(
           searchCriteria(undefined, {
            type: 'CHANGE_SEARCH_CRITERIAA',
            searchCriteria:"title"
          })
        ).toEqual("title")
      })

      it('should handle CHANGE_SORT_CRITERIA when correct action is passed', () => {
        expect(
           sortCriteria({}, {
            type: 'CHANGE_SORT_CRITERIA',
            sortCriteria:"vote_average"
          })
        ).toEqual("vote_average")
      })

      it('should handle CHANGE_SORT_CRITERIA when wrong action is passed', () => {
        expect(
           sortCriteria(undefined, {
            type: 'CHANGE_SORT_CRITERIAA',
            sortCriteria:"vote_average"
          })
        ).toEqual("vote_average")
      })


      it('should handle CHANGE_SEARCH_TEXT when correct action is passed', () => {
        expect(
           searchText({}, {
            type: 'CHANGE_SEARCH_TEXT',
            searchText:"kill"
          })
        ).toEqual("kill")
      })

      it('should handle CHANGE_SEARCH_TEXT when wrong action is passed', () => {
        expect(
           searchText(undefined, {
            type: 'CHANGE_SEARCH_TEXTTT',
            searchText:"kill"
          })
        ).toEqual("")
      })


      it('should handle RELATED_DATA when correct action is passed', () => {
        expect(
           relatedData({}, {
            type: 'RELATED_DATA',
            relatedData:"data"
          })
        ).toEqual("data")
      })

      it('should handle RELATED_DATA when wrong action is passed', () => {
        expect(
           relatedData(undefined, {
            type: 'RELATED_DATAAA',
            relatedData:"data"
          })
        ).toEqual([])
      })

      it('should handle IS_RELATED_DATA_LOADED when correct action is passed', () => {
        expect(
           isRelatedDataLoaded({}, {
            type: 'IS_RELATED_DATA_LOADED',
            isRelatedDataLoaded:true
          })
        ).toEqual(true)
      })

      it('should handle IS_RELATED_DATA_LOADED when wrong action is passed', () => {
        expect(
           isRelatedDataLoaded(undefined, {
            type: 'IS_RELATED_DATA_LOADEDDDD',
            isRelatedDataLoaded:true
          })
        ).toEqual(false)
      })
  })
import React from 'react';
import Enzyme, { shallow,mount } from 'enzyme'
import Adapter from 'enzyme-adapter-react-16'
import MoviePoster from '../components/MoviePoster';

it('check if on click of the component pushes data to history', () => {
  Enzyme.configure({ adapter: new Adapter() })
  const props = {
    data:{
      "poster_path":"http://abc.com",
      "title":"titletest",
      "release_date":"2013",
      "genres":["testgenre1","testgenre2"]
    }
  }
  const historyMock = { push: jest.fn() };
  const enzymeWrapper = shallow(<MoviePoster history={historyMock} {...props} />)
  const movieposter=enzymeWrapper.find('.moviePoster');
  console.log(movieposter);
  movieposter.simulate('click');
  expect(historyMock.push.mock.calls.length).toBe(1);
  })
  
  it('MoviePoster component renders correctly', () => {
    Enzyme.configure({ adapter: new Adapter() })
    const props = {
      data:{
        "poster_path":"http://abc.com",
        "title":"titletest",
        "release_date":"2013",
        "genres":["testgenre1","testgenre2"]
      }
    }
    const historyMock = { push: jest.fn() };
    const enzymeWrapper = shallow(<MoviePoster history={historyMock} {...props} />)
    expect(enzymeWrapper).toMatchSnapshot();
    })


import React from 'react';
import {Film,mapDispatchToProps,mapStateToProps} from '../components/Film';
import Enzyme, { shallow,mount } from 'enzyme'
import Adapter from 'enzyme-adapter-react-16'
import renderer from 'react-test-renderer';
it('App component renders correctly', () => {
    const SearchComponent = renderer.create(<Film/>).toJSON();
    expect(SearchComponent).toMatchSnapshot();
  })
Enzyme.configure({ adapter: new Adapter() })
function setup() {
  const props = {
    getRelatedData:jest.fn(),
    reltedData:{},
    isRelatedDataLoaded:true,
    location:{state:{
      id:2,
      runtime:null,
      vote_average:7.0,
      genre:['genre1','genre2']
    }}
  }
  const historyMock = { replace: jest.fn() };
  const enzymeWrapper = shallow(<Film history={historyMock} {...props} />)
  return {
    props,
    enzymeWrapper
  }
}
it('App component renders correctly', () => {
    const { enzymeWrapper,props } = setup()
    expect(props.location.state.id).toEqual(2);
    
  }) 
  it('test',()=>{
    const props1 = {
      getRelatedData:jest.fn(),
      reltedData:{},
      isRelatedDataLoaded:true,
      location:{state:{
        id:2,
        runtime:200,
        vote_average:0,
        genre:['genre1','genre2']
      }}
    }
    const historyMock = { replace: jest.fn() };
    const enzymeWrapper1 = shallow(<Film history={historyMock} {...props1} />)
    // expect().toEqual(200);
  })

  it('test',()=>{
    const props = {
      getRelatedData:jest.fn(),
      reltedData:{},
      isRelatedDataLoaded:true,
      location:{state:{
        id:2,
        runtime:200,
        vote_average:0,
        genre:['genre1','genre2']
      }}
    }
    const historyMock = { replace: jest.fn() };
    const enzymeWrapper1 = shallow(<Film history={historyMock} {...props} />)
    enzymeWrapper1.find(".searchButtonInFilm").simulate('click');
    // expect().toEqual(200);
  })

  describe('testing map state to props and map dispatch to props', () => {
    it('testing map state to props', () => {
        const initialState = {
            isRelatedDataLoaded:false
        };
        expect(mapStateToProps(initialState).isRelatedDataLoaded).toEqual(false);
    });
    it('testing changeSearchCriteria in map dispatch to props', () => {
        const dispatch = jest.fn();
        mapDispatchToProps(dispatch).getRelatedData("http://react-cdp-api.herokuapp.com/movies?search=kill&searchBy=title&limit=50");
    });
});

it('test',()=>{
  const props = {
    getRelatedData:jest.fn(),
    reltedData:{},
    isRelatedDataLoaded:true,
    location:{state:{
      id:2,
      runtime:200,
      vote_average:0,
      genre:['genre1','genre2']
    }}
  }
  const props1 = {
    getRelatedData:jest.fn(),
    reltedData:{},
    isRelatedDataLoaded:true,
    location:{state:{
      id:3,
      runtime:200,
      vote_average:0,
      genre:['genre1','genre2']
    }}
  }
  const props3 = {
    getRelatedData:jest.fn(),
    reltedData:{},
    isRelatedDataLoaded:true,
    location:{state:{
      id:3,
      runtime:200,
      vote_average:0,
      genre:['genre1','genre2']
    }}
  }
  const historyMock = { replace: jest.fn() };
  const enzymeWrapper1 = shallow(<Film history={historyMock} {...props} />)
  // enzymeWrapper1.find(".searchButtonInFilm").simulate('click');
  enzymeWrapper1.setProps({...props1});
  // expect().toEqual(200);
  enzymeWrapper1.setProps({...props3});
})

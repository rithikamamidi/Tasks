import React from 'react';
import NotFound from '../components/NotFound';
import renderer from 'react-test-renderer';
it('App component renders correctly', () => {
    const SearchComponent = renderer.create(<NotFound/>).toJSON();
    expect(SearchComponent).toMatchSnapshot();
  }) 
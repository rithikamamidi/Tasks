import React from 'react';
import Index from '../index';
import renderer from 'react-test-renderer';
// it('App component renders correctly', () => {
//     const SearchComponent = renderer.create(<Index/>).toJSON();
//     expect(SearchComponent).toMatchSnapshot();
//   })
//   import React from 'react';
  import ReactDOM from 'react-dom';
  
  
  it('renders without crashing', () => {
  const div = document.createElement('div');
  ReactDOM.render(<Index />, div);
  ReactDOM.unmountComponentAtNode(div);
  }); 
   
  
import React from 'react';
import DisplayFetchedData from '../components/DisplayFetchedData';
import renderer from 'react-test-renderer';

it('test if display fetched data is rendered correctly', () => {
    const props = {
        data:[{
          "poster_path":"http://abc.com",
          "title":"titletest",
          "release_date":"2013",
          "id":12,
          "genres":["testgenre1","testgenre2"]
        }]
      }
    const displayComponent = renderer.create(<DisplayFetchedData {...props}/>).toJSON();
    expect(displayComponent).toMatchSnapshot();
  }) 
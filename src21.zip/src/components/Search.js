import React, { Component } from 'react';
import '../css/Search.css';
import DisplayFetchedData from './DisplayFetchedData';
import {fetchDataFunction,changeSearchCriteria,changeSortCriteria,setData,changeSearchText} from '../actions/actions';
import { connect } from 'react-redux'

export class Search extends Component {
    constructor(props) {
        super(props);
        this.searchInput = React.createRef();
    }
    handleSearchCriteriaChange=(event) =>{
        this.props.changeSearchCriteria(event.target.id);
    }
    getSortOrder(prop) {  
        return function(a, b) {  
            if (a[prop] < b[prop]) {  
                return 1;  
            } else if (a[prop] > b[prop]) {  
                return -1;  
            }  
            return 0;  
        }  
    }
    handleSort=(event)=> {
        this.props.changeSortCriteria(event.target.id);
        var sortedData=this.props.data.sort(this.getSortOrder(event.target.id));
        console.log(sortedData);
        this.props.setSortedData(sortedData);

    }
    handleKeyPress=(event)=> {
        if (event.key === 'Enter') {
            event.preventDefault(); 
            this.handleSearch();
        }
      }
    handleSearch=()=>{
        var query="http://react-cdp-api.herokuapp.com/movies?sortBy="+this.props.sortCriteria+
            "&sortOrder=desc&search="+this.props.searchText
            +"&searchBy="+this.props.searchCriteria+"&limit=50";
        console.log("inside search");
        this.props.fetchDataFn(query);
    }
    updateSearchValue=(event)=>{
        this.props.updateSearchText(event.target.value);
    }
    showFetchedData(dataLoaded,isloading){
        if(!dataLoaded && !isloading){
            return <h1 className="alignCenter">Search for movies</h1>
        }
        else if(isloading && !dataLoaded){
            return <h1>loading..</h1>
        }
        return (
            <>
            <div className="bgBlackColor">
                <label>{this.props.data.length} films found</label>
                <div className="alignEnd">
                    <label className="">Sort by</label>
                    <button value="release date" style={{background:this.props.sortCriteria==='release_date'?'red':'grey'}} className="criteriaButton" id="release_date" onClick={this.handleSort}>Release Date</button>
                    <button value="rating" style={{background:this.props.sortCriteria==='vote_average'?'red':'grey'}} className="criteriaButton" id="vote_average" onClick={this.handleSort}>Rating</button>
                </div>
            </div>
            {this.props.data.length!==0 ? (<DisplayFetchedData data={this.props.data} history={this.props.history}/>) : (<h1 style={{textAlign:'center'}}>No films found</h1>)}
            </>
        )
    }
    render() {
        // console.log(this.props);
       return (
           <div className="backgroundBlack">
               <div className="div">
                    <div className="text">
                        <p className="redText">netflix roulette</p>
                        <form className="form">
                            <label className="label">
                                FIND YOUR MOVIE<br/>
                            </label>
                            <input type="text" name="name" onKeyPress={this.handleKeyPress} className="searchBox" onChange={this.updateSearchValue}/>
                            <br/>
                            <div className="buttonDiv">
                                <span className="spanStyle">Search by</span>
                                <input type="button" style={{background:this.props.searchCriteria==='title'?'red':'grey'}} value="TITLE" className="criteriaButton" id="title" onClick={this.handleSearchCriteriaChange}/>
                                <input type="button" style={{background:this.props.searchCriteria==='genres'?'red':'grey'}} value="GENRE" className="criteriaButton" id="genres" onClick={this.handleSearchCriteriaChange}/>
                                <input type="button" value="SEARCH" className="searchButton" onClick={this.handleSearch}/>
                            </div>
                        </form>    
                    </div>
                </div>
                {this.showFetchedData(this.props.isLoaded,this.props.isLoading)}     
           </div>
           
      );
    }
  }
  export const mapStateToProps = state => ({
      data:state.data,
      isLoaded: state.isLoaded,
      searchCriteria:state.searchCriteria,
      sortCriteria:state.sortCriteria,
      searchText:state.searchText,
      isLoading:state.isLoading
  });
  export const mapDispatchToProps = dispatch => ({
      fetchDataFn: (url) => dispatch(fetchDataFunction(url)),
      changeSearchCriteria: (searchCriteria)=>dispatch(changeSearchCriteria(searchCriteria)),
      updateSearchText: (searchText)=>dispatch(changeSearchText(searchText)),
      setSortedData:(data)=>dispatch(setData(data)),
      changeSortCriteria:(sortCriteria)=>dispatch(changeSortCriteria(sortCriteria))
});
export default connect(mapStateToProps,mapDispatchToProps)(Search);
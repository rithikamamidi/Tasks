import React, { Component } from 'react';
class NotFound extends Component {
    render() {
      return (
        <div>
            <h1>Not found</h1>
            {/* {console.log(this.props.location.state)} */}
        </div>
      );
    }
  }
  
  export default NotFound;
  
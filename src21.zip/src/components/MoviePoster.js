import React, { Component } from 'react';
import '../css/Movie.css';
// import history from '../history/history';
class MoviePoster extends Component {
  changeUrl(data){
    console.log("in change")
    this.props.history.push({pathname:"/film/"+data['id'],state:{id:data['id'],
                                                      overview:data['overview'],
                                                      title:data['title'],
                                                      runtime:data['runtime'],
                                                      vote_average:data['vote_average'],
                                                      poster_path:data['poster_path'],
                                                      genre:data['genres'],
                                                      tagline:data['tagline'],
                                                      release_date:data['release_date'].substring(0,4)
                                                    }})
  } 
  render() {
    // console.log(this.props);
    return (
      <div className="moviePoster" onClick={()=>this.changeUrl(this.props.data)}>
      <img src={this.props.data['poster_path']} alt="alt" className="imageStyle"/>
        <div>
          <label className="titleStyleInPoster">{this.props.data['title'].toUpperCase()}</label>
          <label className="dateInPoster">{this.props.data['release_date'].substring(0, 4)}</label><br/>
          <label>{this.props.data['genres'][0]}</label>
        </div>
      </div>
    );
  }
}

export default MoviePoster;




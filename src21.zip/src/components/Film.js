import React, { Component } from 'react';
import '../css/Film.css';
import {getRelatedData} from '../actions/actions';
import { connect } from 'react-redux'
import DisplayFetchedData from './DisplayFetchedData';

export class Film extends Component {
      componentDidMount(){
        this.fetchData();
      }
      async fetchData(){        
        var query2="http://react-cdp-api.herokuapp.com/movies?search="+this.props.location.state.genre[0]+"&searchBy=genres&limit=50";
        this.props.getRelatedData(query2);
      }
      componentDidUpdate(prevProps){
        if(prevProps.location.state.id !== this.props.location.state.id){
          this.fetchData();
          window.scrollTo(0,0);
        }
      }
      displayDuration(){
        if(this.props.location.state.runtime===null){
          return "";
        }
        else {
          return this.props.location.state.runtime+" mins";
        }
      }
      displayVoteAverage(){
        if(this.props.location.state.vote_average===0){
          return "";
        } else{
          return <span className="circledRating">{this.props.location.state.vote_average}</span>
        }
      }
      searchClicked=()=>{
         this.props.history.replace("/");
      }

    render() {
      // console.log(this.props);
      if(!this.props.isRelatedDataLoaded){
        return <h1>loading..</h1>
      }
        return (
          <div className="totalContainer">
          <div className="bgblack">
            <span className="redText">netflix roulette</span>
            <br/>
            <button value="Search" className="searchButtonInFilm" onClick={this.searchClicked}>Search</button>
            <img src={this.props.location.state.poster_path} alt="alternate" className="imageStyle1"/>
            
            <div className="floatLeft">
              <h3 style={{color:'red'}}>{this.props.location.state.title}</h3>
              {this.displayVoteAverage()}
              <p>{this.props.location.state.tagline}</p>
              {/* {console.log("id",this.props.match.params.id)} */}
              <div className="divWidth">
                <label className="datelabel">{this.props.location.state.release_date}</label>
                <label> {this.displayDuration()} </label>
              </div>
              <p>{this.props.location.state.overview}</p>
          </div>
          </div>
          <div className="clear"></div>
          <span className="displayText">Films by {this.props.location.state.genre[0]} genre</span>
          <DisplayFetchedData data={this.props.relatedData} history={this.props.history}/>
          </div>
        )
    }
  }
  export const mapStateToProps = state => ({
    isRelatedDataLoaded:state.isRelatedDataLoaded,
    relatedData:state.relatedData
});
export const mapDispatchToProps = dispatch => ({
    getRelatedData:(url)=> dispatch(getRelatedData(url))

});
export default connect(mapStateToProps,mapDispatchToProps)(Film);

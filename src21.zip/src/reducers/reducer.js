export function isLoaded(state = false, action) {
  switch (action.type) {
      case 'IS_LOADED':
          return action.isLoaded;
      default:
          return state;
  }
}

export function data(state = [], action) {
  switch (action.type) {
      case 'FETCHED_DATA':
        return action.data;
      default:
        return state;
    }
}
export const searchCriteria = (state="title", action)=>{
  switch (action.type) {
    case 'CHANGE_SEARCH_CRITERIA':
        return action.searchCriteria;

    default:
        return state;
    }
}

export const sortCriteria = (state="vote_average", action)=>{
  switch (action.type) {
    case 'CHANGE_SORT_CRITERIA':
        return action.sortCriteria;

    default:
        return state;
}
}

export const searchText=(state="",action)=>{
  switch(action.type) {
    case 'CHANGE_SEARCH_TEXT':
        return action.searchText;
    default:
        return state;    
  }
}

export const isLoading=(state=false,action)=>{
  switch(action.type) {
    case 'IS_LOADING':
        return action.isLoading;
    default:
        return state;    
  }
}

export function relatedData(state = [], action) {
  switch (action.type) {
      case 'RELATED_DATA':
          return action.relatedData;

      default:
          return state;
  }
}

export function isRelatedDataLoaded(state=false,action){
  switch (action.type) {
    case 'IS_RELATED_DATA_LOADED':
        return action.isRelatedDataLoaded;

    default:
        return state;
  }
}

export  const  changeSearchCriteria = (searchCriteria)=>({
    type:'CHANGE_SEARCH_CRITERIA',
    searchCriteria
})
export const changeSortCriteria = (sortCriteria)=>({
    type:'CHANGE_SORT_CRITERIA',
    sortCriteria
})
export const changeSearchText = (searchText)=>({
    type:'CHANGE_SEARCH_TEXT',
    searchText
})
export const setData = (data) =>({
    type:'FETCHED_DATA',
    data
})
export const dataIsLoaded=(bool)=>{
    return {
        type: 'IS_LOADED',
        isLoaded: bool
    };
}
export const isLoading=(isLoading)=>{
    return {
        type:'IS_LOADING',
        isLoading
    }
}
export const fetchDataFunction=(url)=>{
    console.log("in get data");
    return (dispatch) => {
       dispatch(isLoading(true));
        return fetch(url)
            .then((response) => {
                if (!response.ok) {
                    throw Error(response.statusText);
                }
                return response;
            })
            .then((response) => response.json())
            .then(jsonData=>jsonData["data"])
            .then((data) => dispatch(setData(data)))
            .then(()=>dispatch(dataIsLoaded(true)))
            .then(()=>dispatch(isLoading(false)))
    };
}
export const getRelatedData=(url)=>{
    console.log("in get data");
    return (dispatch) => {
       return fetch(url)
           .then((response) => {
               if (!response.ok) {
                   throw Error(response.statusText);
               }
               return response;
           })
           .then((response) => response.json())
           .then(jsonData=>{
            return jsonData["data"];
           })
           .then((data) => dispatch(setRelatedData(data)))
           .then(()=>dispatch(setRelatedDataLoaded(true)))
   };
}
export const setRelatedDataLoaded=(isRelatedDataLoaded)=>{
    return {
        type:'IS_RELATED_DATA_LOADED',
        isRelatedDataLoaded
    }
}
export const setRelatedData=(relatedData)=>{
    return {
        type:'RELATED_DATA',
        relatedData
    }
}





import React from 'react';
import ReactDOM from 'react-dom';
import Search from './components/Search';
test('two plus two is four', () => {
  expect(2 + 2).toBe(4);
});
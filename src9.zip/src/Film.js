
import React, { Component } from 'react';
import './Film.css';
import MoviePoster from './Movie'
import history from './history';

class Film extends Component {
    constructor(props) {
        super(props);
        this.state = {id:this.props.location.state.id,dataLoaded:false,fetchedData:{},relatedData:{}};
      }
      componentDidMount(){
        this.fetchData();
      }
      async fetchData(){
        // console.log("hhhhhh"+this.state.id);
        var query="http://react-cdp-api.herokuapp.com/movies/"+this.props.location.state.id;
             await fetch(query).then(result=>result.json())
            .then(result=>this.setState({fetchedData:{result}}))
            
        var query2="http://react-cdp-api.herokuapp.com/movies?search="+this.state.fetchedData.result.genres[0]+"&searchBy=genres&limit=50";
        await fetch(query2).then(result=>result.json())
            .then(jsonData=>jsonData["data"])
            .then(result=>this.setState({relatedData:{result}}))
            .then(()=>this.setState({dataLoaded:true}))
            console.log(this.state.relatedData);
      }
      componentDidUpdate(prevProps){
        // console.log("hi");
        if(prevProps.location.state.id !== this.props.location.state.id){
          // console.log("callinf fetch data");
          this.fetchData();
          window.scrollTo(0,0);

        }
      }

      clicked(id){
        this.setState({id:{id}});
        console.log("in clicked")
        console.log(this.state.id);

      }
      displayDuration(){
        if(this.state.fetchedData.result.runtime===null){
          return "";
        }
        else {
          return this.state.fetchedData.result.runtime+" mins";
        }
      }
      displayVoteAverage(){
        if(this.state.fetchedData.result.vote_average===0){
          return "";
        } else{
          return <span className="circledRating">{this.state.fetchedData.result.vote_average}</span>
        }
      }
      searchClicked(){
        history.replace("/");
       
      }

    render() {
      console.log(this.state.dataLoaded);
      console.log(this.state.fetchedData)
      if(this.state.dataLoaded){
        return (
          <div className="totalContainer">
          <div className="bgblack">
            <span className="redText">netflix roulette</span>
            <br/>
            <button value="Search" className="searchButtonInFilm" onClick={this.searchClicked}>Search</button>
            <img src={this.state.fetchedData.result.poster_path} alt="alternate" className="imageStyle1"/>
            
            <div className="floatLeft">
              <h3 style={{color:'red'}}>{this.state.fetchedData.result.title}</h3>
              {this.displayVoteAverage()}
              <p>{this.state.fetchedData.result.tagline}</p>
              <div className="divWidth">
                <label className="datelabel">{this.state.fetchedData.result.release_date.substring(0, 4)}</label>
                <label> {this.displayDuration()} </label>
              </div>
              <p>{this.state.fetchedData.result.overview}</p>
          </div>
          </div>
          {/* <div className="clear"></div> */}
          <span className="displayText">Films by {this.state.fetchedData.result.genres[0]} genre</span>

          <div className="displayInGrid">
          {/* <div className="">
              <label>{this.props.data.result.length} films found</label>
              <label className="">Sort by</label>
              <button value="release date">Release Date</button>
              <button value="rating">Rating</button>
            </div> */}
              {this.state.relatedData.result.map(i => {
                return <MoviePoster key={i['id']} data={i} onClick={()=>this.clicked(i['id'])}/>
              })}
            
      </div>
          </div>
        )
      }
      else {
        return <h1>loading..</h1>
      }
    }
  }
  export default Film;
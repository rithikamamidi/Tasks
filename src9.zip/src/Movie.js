import React, { Component } from 'react';
import './Movie.css';
import history from './history';
class MoviePoster extends Component {
  constructor(props) {
    super(props);
    this.test = this.test.bind(this);
  }
  test(value){
    history.push({pathname:"/film/"+value,state:{id:value}})
  }
    //history.push("/hhh");
 
  render() {
    // const greeting = 'Welcome to React';
    return (
      // <div className="moviePoster" onClick={()=>this.test(this.props.data['id'])}>
      // <div className="moviePoster" onClick={()=>history.push({pathname:"/film",state:{id:this.props.data['id']}})}>
      <div className="moviePoster" onClick={()=>this.test(this.props.data['id'])}>
      {/* {console.log(this.props.data.result[0])} */}
      {/* {console.log(this.props.data.result[0]['poster_path'])} */}
      {/* {image1= this.props.data.result[0]['poster_path']} */}
      <img src={this.props.data['poster_path']} alt="alt" className="imageStyle"/>
        <div>
          <label className="titleStyleInPoster">{this.props.data['title'].toUpperCase()}</label>
          <label className="dateInPoster">{this.props.data['release_date'].substring(0, 4)}</label><br/>
          <label>{this.props.data['genres'][0]}</label>
        </div>
      </div>
    );
  }
}

export default MoviePoster;





export const changeSearchCriteria = (clickedId)=>({
    type:'CHANGE_SEARCH_CRITERIA',
    clickedId
})
export const changeSortCriteria = (clickedId)=>({
    type:'CHANGE_SORT_CRITERIA',
    clickedId
})
export const changeSearchText = (text)=>({
    type:'CHANGE_SEARCH_TEXT',
    text
})
export const fetchData = () => ({
    type:'FETCH_DATA',
    text:'fetching data action'
})
const reducer = (state = [], action) => {
    switch (action.type) {
      case 'CHANGE_SEARCH_CRITERIA':
        return [
          {
              text:'hello'
          }
        ]
      default:
        return state
    }
  }
  
  export default reducer
import React, { Component } from 'react';
import './Search.css';

class Search extends Component {
    constructor(props) {
        super(props);
        this.state = {title:true,genre:false,isFetching:false,searchByName:''};
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
      }
    
      handleChange(event) {
          alert(event.target.id);
      }
    
      handleSubmit() {
          this.setState({isFetching:false});
      }
    
    
    render() {
       return (
           <div className="div">
               <form className="form">
                    <label>
                        FIND YOUR MOVIE
                        <input type="text" name="name" className="searchBox"/>
                    </label>
                    <br/><br/>
                    <span>Search by</span>
                    <input type="button" value="TITLE" className="criteriaButton" id="title" onClick={this.handleChange}/>
                    <input type="button" value="GENRE" className="criteriaButton" id="genre" onClick={this.handleChange}/>
                    <input type="submit" value="SEARCH" className="searchButton"/>


               </form>    
           </div>
      );
    }
  }
  
  export default Search;
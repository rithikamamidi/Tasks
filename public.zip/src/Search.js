import React, { Component } from 'react';
import './Search.css';
import DisplayFetchedData from './DisplayData';

class Search extends Component {
    constructor(props) {
        super(props);
        this.searchInput = React.createRef();
        this.state = {title:true,dataLoaded:false,searchByName:'',fetchedData:{}};
        this.handleChange = this.handleChange.bind(this);
        this.handleSearch = this.handleSearch.bind(this);
        this.updateSearchValue = this.updateSearchValue.bind(this);
      }
    
      handleChange(event) {
          if(event.target.id==="title"){
              this.setState({title:true})
              console.log(this.state.title+""+this.state.genre);
          } else{
              this.setState({title:false})
              console.log(this.state.title+""+this.state.genre);
          }
        }
       handleSearch= async()=> {
          var searchCriteria = this.state.title ? "title" : "genres";
          var query="http://react-cdp-api.herokuapp.com/movies?search="+this.state.searchByName+"&searchBy="+searchCriteria;
          await fetch(query)
            .then(results =>{
                return results.json();
            })
            .then(jsonData=>jsonData["data"])
            .then(result=>this.setState({fetchedData:{result}}))
            console.log(this.state.fetchedData);
            this.setState({dataLoaded:true})
      }
      updateSearchValue(e){
        this.setState({
            searchByName:e.target.value
        })
      }
      callDisplay(dataLoaded){
          console.log("inside call display");
         if(dataLoaded){
             return <DisplayFetchedData data={this.state.fetchedData}/>
         }
         return <h1>no movies</h1>
      }
    render() {
       return (
           <div className="backgroundBlack">
               <div className="div">
                    <p className="redText">netflix application</p>
                    <form className="form">
                        <label className="label">
                            FIND YOUR MOVIE<br/>
                        </label>
                        <input type="text" name="name" className="searchBox" onChange={this.updateSearchValue}/>
                        <br/>
                        <div className="buttonDiv">
                            <span className="spanStyle">Search by</span>
                            <input type="button" value="TITLE" className="criteriaButton" id="title" onClick={this.handleChange}/>
                            <input type="button" value="GENRE" className="criteriaButton" id="genre" onClick={this.handleChange}/>
                            <input type="button" value="SEARCH" className="searchButton" onClick={this.handleSearch}/>
                        </div>
                    </form>    
                </div>
                {this.callDisplay(this.state.dataLoaded)}     
           </div>
           
      );
    }
  }
  export default Search;
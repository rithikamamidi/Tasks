import React, { Component } from 'react';
import MoviePoster from './Movie';
import './displayData.css'
class DisplayFetchedData extends Component {
  render() {
    return (
      <div className="displayInGrid">
          {/* {console.log(this.props.data.result[0])} */}
          {/* {console.log(this.props.data.result[0]['poster_path'])} */}
          {/* {image1= this.props.data.result[0]['poster_path']} */}
          {/* <img src={this.props.data.result[0]['poster_path']} alt="alt"/> */}
          <div>
              <label>{this.props.data.result.length}films found</label>
              <label>Sort by</label>
              <button value="release date">Release Date</button>
              <button value="rating">Rating</button>
            </div>  
          <MoviePoster data={this.props.data.result[0]}/>
          <MoviePoster data={this.props.data.result[1]}/>
          <MoviePoster data={this.props.data.result[2]}/>
      </div>
    );
  }
}

export default DisplayFetchedData;
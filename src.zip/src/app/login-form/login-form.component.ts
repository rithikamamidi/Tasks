import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';

@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.css']
})
export class LoginFormComponent implements OnInit {

  signUpForm = this.formBuilder.group({
    firstName:['',Validators.compose([Validators.required,Validators.maxLength(10),Validators.minLength(4)])],
    email:['',Validators.required],
    password:['',Validators.required],
    confirmPassword:['',Validators.required]
  });
  constructor(private formBuilder:FormBuilder) { }

  ngOnInit() {
  }
  onSubmit(){
    console.log(this.signUpForm.value)
    console.log(this.signUpForm)
  }

}

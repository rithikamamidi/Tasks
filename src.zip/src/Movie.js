import React, { Component } from 'react';
import './Movie.css'
class MoviePoster extends Component {
  render() {
    return (
      <div className="moviePoster">
      {/* {console.log(this.props.data.result[0])} */}
      {/* {console.log(this.props.data.result[0]['poster_path'])} */}
      {/* {image1= this.props.data.result[0]['poster_path']} */}
      <img src={this.props.data['poster_path']} alt="alt" className="imageStyle"/>
        <div>
          <label className="titleStyleInPoster">{this.props.data['title'].toUpperCase()}</label>
          <label className="dateInPoster">{this.props.data['release_date'].substring(0, 4)}</label><br/>
          <label>{this.props.data['genres'][0]}</label>
        </div>
      </div>
    );
  }
}

export default MoviePoster;




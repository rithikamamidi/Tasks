import React, { Component } from 'react';
import './Search.css';

class Search extends Component {
    constructor(props) {
        super(props);
        this.state = {title:true,genre:false,isFetching:false,searchByName:''};
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
      }
    
      handleChange(event) {
          alert(event.target.id);
      }
    
      handleSubmit(e) {
          e.preventDefault();
          alert(this.state.isFetching);
      }
    
    
    render() {
       return (
           <div className="div">
               <form className="form">
                    <label className="label">
                        FIND YOUR MOVIE<br/>
                    </label>
                        <input type="text" name="name" className="searchBox"/>
                    <br/>
                    <div className="buttonDiv">
                        <span className="spanStyle">Search by</span>
                        <input type="button" value="TITLE" className="criteriaButton" id="title" onClick={this.handleChange}/>
                        <input type="button" value="GENRE" className="criteriaButton" id="genre" onClick={this.handleChange}/>
                        <input type="submit" value="SEARCH" className="searchButton"/>
                    </div>
               </form>    
           </div>
      );
    }
  }
  
  export default Search;
import React, { Component } from 'react';
import MoviePoster from './Movie';
import './displayData.css'
class DisplayFetchedData extends Component {
  render() {
    return (
      <div className="displayInGrid">
          {/* <div className="">
              <label>{this.props.data.result.length} films found</label>
              <label className="">Sort by</label>
              <button value="release date">Release Date</button>
              <button value="rating">Rating</button>
            </div> */}
            <div className="movieResults">
              {this.props.data.result.map(i => {
                return <MoviePoster data={i}/>
              })}
            </div>
            
      </div>
    );
  }
}

export default DisplayFetchedData;